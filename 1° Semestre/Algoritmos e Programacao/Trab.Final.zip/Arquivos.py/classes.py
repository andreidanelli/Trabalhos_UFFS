LIMITE_CREDITO = 1000

class Produtos:
    def __init__(self, codigo, produto, preco):
        self.codigo = codigo
        self.produto = produto
        self.preco = preco

    #Exibe o o código e o nome do produto, toda vez que o objeto é chamado
    def __str__(self):
        return f'Código: {self.codigo}, Produto: {self.produto}, Preço: {self.preco}'

    # Função para retornar os código, nomes e precos dos produtos
    def exibe_produtos_cadastrados(self):
        return f'\nCódigo: {self.codigo} \nNome do Produto: {self.produto} \nValor: {self.preco}'


class Clientes:
    def __init__(self, cpf, usuario, senha, email):
        self.cpf = cpf
        self.usuario = usuario
        self.senha = senha
        self.email = email
        self.limite_credito = LIMITE_CREDITO

    def __str__(self):
        return f'CPF: {self.cpf}, Nome do Usuário: {self.usuario}, Email: {self.email}, Limite de Crédito: {self.limite_credito}'


class Carrinho:
    def __init__(self, cpf):
        self.cpf = cpf
        self.itens =''

    def __str__(self):
        return f'{self.cpf}'

class Item_Carrinho:
    def __init__(self, prod, qtd, preco):
        self.prod = prod
        self.qtd = qtd
        self.valor = preco
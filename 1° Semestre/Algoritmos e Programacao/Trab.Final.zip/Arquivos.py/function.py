from pip._internal.models.link import Link

from classes import *
from validacpf import *
#------------------------

# Clientes
lista_clientes = []

# Produtos - pode adicionar quantos produtos desejar
lista_produtos = [
    Produtos(codigo=1, produto="Arroz 5 kg", preco=10.00),
    Produtos(codigo=2, produto="Feijão 1 kg", preco=40.00),
    Produtos(codigo=3, produto="Açucar 1 kg", preco=50.),
    Produtos(codigo=4, produto="Café", preco=50.00),
    Produtos(codigo=5, produto="Óleo de soja", preco=50.00),
    Produtos(codigo=6, produto="Sal", preco=50.00),
    Produtos(codigo=7, produto="Macarrão", preco=50.00),
    Produtos(codigo=8, produto="Carnes", preco=50.00),
    Produtos(codigo=9, produto="Leite", preco=50.00),
    Produtos(codigo=10, produto="Farinha", preco=50.00),
    Produtos(codigo=11, produto="Iogurte", preco=50.00),
    Produtos(codigo=12, produto="Queijo", preco=50.00),
    Produtos(codigo=13, produto="Hortaliças", preco=50.00),
    Produtos(codigo=14, produto="Ovos", preco=50.00),
    Produtos(codigo=15, produto="Pães", preco=50.00),
    Produtos(codigo=16, produto="Temperos", preco=50.00),
    Produtos(codigo=17, produto="Biscoitos", preco=50.00),
    Produtos(codigo=18, produto="Molho de tomate", preco=50.00),
    Produtos(codigo=19, produto="Frutas", preco=50.00),
    Produtos(codigo=20, produto="Chocolate", preco=50.00),
]

# Carrinho
carrinhos = []
item_carrinho = []

#---------------------------------------------------------------------------------------------------------------------------------------------------------
#Funções

# cadastro de novos clientes
# verificar se o cliente já existe a partir do cpf
def cadastro():
    cpf = input("\nDigite o CPF: ")
    if is_cpf_valido(cpf):
        result = any(cpf == cli.cpf for cli in lista_clientes)
        if not result:
            usuario = (input("Digite o nome do usuário: "))
            senha = (input("Digite a senha: "))
            email = (input("Informe um e-mail: "))
            lista_clientes.append(Clientes(cpf, usuario, senha, email))
            carrinhos.append(Carrinho(cpf))
            print('\nParabéns, cadastro realizado com sucesso!!')
            print(f'Seu limite de crédito é de R$:', LIMITE_CREDITO)
        else:
            for i in range(len(lista_clientes)):
                if cpf == lista_clientes[i].cpf:
                    print("Cliente já cadastrado com o nome de: ", lista_clientes[i].username)
    else:
        print('CPF Inválido!')


#Função para exibir produtos e adicionar ao carrinho
def comprar():
    cpf = input("Digite o CPF: ")
    senha = input("Digite a senha: ")
    for cli in lista_clientes:
        if cpf == cli.cpf and senha == cli.senha:
            print(f"\nBem-Vindo(a) as compras Sr(a)",  cli.usuario)
            #Verificando se o carrinho está vazio!
            for car in carrinhos:
                if car.cpf == cli.cpf:
                    if car.itens == None:
                        # Após verificar carrinho vazio usuário escolhe se quer comprar
                        print('Seu carrinho está vazio!')
                        comprar = input('Deseja comprar algo (s/n)? ')
                        if comprar == 's' or comprar == 'S':
                            adiciona_itens_carrinho(comprar, cli, car)
                    else:
                        print(f'Valor Disponivel R$ {cli.limite_credito}')
                        comprar = input('Deseja comprar mais alguma coisa (s/n)? ')
                        # Após verificar carrinho com item usuário escolhe se quer continuar comprando
                        if comprar == 's' or comprar == 'S':
                            adiciona_itens_carrinho(comprar, cli, car)
                        else:
                            print('Volte sempre!')


# Verifica se o código está cadastrado na lista
def adiciona_itens_carrinho(comprar, cliente, car):
    exibe_produtos()
    while comprar == 's' or comprar == 'S':
        n = int(input('Digite o código do produto que deseja: '))
        for prod in lista_produtos:
            if n == prod.codigo:
                qtd = int(input('Digite a quantidade que deseja: '))
                total = calcula_total_carrinho(car)
                total_carrinho = total + prod.preco * qtd
                if total_carrinho <= LIMITE_CREDITO:
                    item_carrinho = Item_Carrinho(prod, qtd, prod.preco)
                    itens_carrinho = retorna_itens_carrinho(car)
                    itens_carrinho.append(item_carrinho)
                    car.itens = itens_carrinho
                    cliente.limite_credito -= (prod.preco * qtd)
                    print('Inserido no carrinho')
                else:
                    print('\n***limite estourado! Pague suas compras para liberar seu limite!***')
                    print(f'\nTotal desta compra: {prod.preco * qtd}')
                    print(f'\nTotal do Carrinho: {total_carrinho}')
                    StopIteration()
        comprar = input('Continuar Comprando (s/n)? ')
    print('\nVolte sempre!!!')


# Função para Exibir os produtos cadastrados
def exibe_produtos():
    for l in lista_produtos:
        print(Produtos.exibe_produtos_cadastrados(l))


# Mostrar o carrinho de compras
def exibe_carrinho(car):
    if len(car.itens) != 0:
        for item in car.itens:
            print(f'Código: {item.prod.codigo}, Produto: {item.prod.produto} Quantidade: {item.qtd} Valor: {item.valor} Total: {item.qtd * item.valor}')
    else:
        print('Não há nenhum item no carrinho!')


def retorna_itens_carrinho(car):
    itens = []
    if car.itens != None:
        for item in car.itens:
            itens.append(item)
    return itens


def detalhar_carrinho():
    cpfcli = input('\nInforme o CPF: ')
    for cli in lista_clientes:
        if cpfcli == cli.cpf:
            for car in carrinhos:
                if cpfcli == car.cpf:
                    total = calcula_total_carrinho(car)
                    print(f'Limite de Crédito R$ {LIMITE_CREDITO}\nValor gasto R$ {total}\nValor Disponivel R$ {LIMITE_CREDITO - total}')
                    detalhar_compra = input('\nDetalhar compras (s/n)?')
                    if detalhar_compra == 's' or detalhar_compra == 'S':
                        exibe_carrinho(car)
                    else:
                        print('Saindo...')


#Efetua pagamento das compras
def efetuar_pagamento():
    cpf = input('Informe o CPF:')
    pagar = input('Deseja realizar o pagamento (s/n):')
    if pagar == 's' or pagar == 'S':
        for cli in lista_clientes:
            if cli.cpf == cpf:
                for car in carrinhos:
                    if car.cpf == cli.cpf:
                        total = calcula_total_carrinho(car)
                        print(f'\nPagamento realizado com sucesso!!! Valor: R$ {total}')
                        cli.limite_credito = LIMITE_CREDITO
                        car.itens.clear()


# mostra um cliente a partir do cpf
def consulta_cliente():
    cpf = input("Qual o cpf que deseja consultar? Digite o CPF: ")
    for i in range(len(lista_clientes)):
        if cpf == lista_clientes[i].cpf:
            print('Cliente cadastrado com o nome: ', lista_clientes[i].usuario)
        else:
            print('\nNão existe cliente em nossa base de dados com este CPF')


#Calcula o total do carrinho para pagar
def calcula_total_carrinho(car):
    total = 0
    if car.itens != None:
        for item in car.itens:
            total += item.qtd * item.valor
    return total


def remove_itens_carrinho():
    cpf = input('Digite o seu CPF: ')
    codigo = int(input('Digita um código que deseja remover: '))
    for car in carrinhos:
        if car.cpf == cpf:
           itens = retorna_itens_carrinho(car)
           for item in itens:
               if item.prod.codigo == codigo:
                   itens.remove(item)
                   print('Item removido!')
           car.itens = itens



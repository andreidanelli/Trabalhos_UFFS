from function import *
# -------------------------
# menu principal
index = 0

def menu():
    opcao = "-1"
    while opcao != "0":
        print('\n')
        print('-=' * 30)
        print("""Menu:
                1 - Cadastro
                2 - Comprar
                3 - Mostrar carrinho
                4 - Pagar conta
                5 - Consultar cliente
                6 - Mostrar produtos
                7 - Remover itens do carrinho
                0 - Sair""")
        print('-=' * 30)
        opcao = input('Insira uma opção: ')
        if opcao == "1":
            print("Opção selecionada: Cadastro")
            cadastro()

        elif opcao == "2":
            print("Opção selecionada: Comprar")
            comprar()

        elif opcao == "3":
            print("Opção selecionada: Mostrar carrinho")
            print('-=' * 30)
            detalhar_carrinho()


        elif opcao == "4":
            print("Opção selecionada: Pagar conta")
            efetuar_pagamento()

        elif opcao == "5":
            print("Opção selecionada: Consultar cliente")
            consulta_cliente()

        elif opcao == "6":
            print("Opção selecionada: Mostrar produtos na prateleira")
            exibe_produtos()

        elif opcao == "7":
            print("Opção selecionada: Remover itens do carrinho")
            remove_itens_carrinho()

        elif opcao == "0":
            print("Saindo...")

        else:
            print("Opção inválida! Tente novamente.")

menu()
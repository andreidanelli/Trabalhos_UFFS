#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM_NAME 40

//******Structs*********
//************************

struct date
{
	int day, month, year;
};
typedef struct date Date;

struct student
{
  int registration;
  char name[TAM_NAME];
  Date birth;
  float average ;
  struct student *next;
};
typedef struct student Student;

//******Functions*********
//************************

//Register Students
Student *registerStudent(Student *s)
{
	Student *student1 = (Student *)malloc(sizeof(Student));

	scanf("%d\n", &student1->registration);
	scanf("%s\n", student1->name);
	scanf("%d/%d/%d\n", &student1->birth.day, &student1->birth.month, &student1->birth.year);
	scanf("%f\n", &student1->average);
    student1->next = s;

    return(student1);
}

//List registered students
void printStudent(Student *s)
{
 	if (s==NULL)
	 {
	 	printf("Lista Vazia!\n");
	 }
	 else
	 {
	 	while(s!=NULL)
		 {
	 		printf("%d, %s, %d/%d/%04d, %.2f\n", s->registration, s->name, s->birth.day, s->birth.month, s->birth.year, s->average);
	 		s = s->next;
		 }
	 }
}

//Delete Students from the list
Student *deleteStudent(Student *s, int id){

	Student *aux, *prev=s;
	for(aux=s;aux!=NULL;aux=aux->next){
		if(aux->registration == id){
			if(aux==s){
				s=s->next;
				for(prev=s;prev!=NULL;prev=prev->next)
					prev->registration;
				break;
			}
			prev->next=aux->next;
			for(prev=aux->next;prev!=NULL;prev=prev->next)
				prev->registration;
			break;
		}
		prev=aux;
	}
	if (aux!=NULL){
		free(aux);
	}
	return s;
}

//Sum the total number of students
void countStudent(Student *s){
	int i = 0;

	if (s==NULL){
		printf("0\n");
	}else{
		while(s!=NULL){
			s = s->next;
			i++;
		}
		printf("%d\n", i);
	}
}

void print(Student *s){
	if (s!=NULL){
		while (s!=NULL){
			printf("-");
		s = s->next;
		}
	}
}

void printListInverse(Student *s){
	if (!s)
		return;
	printListInverse(s->next);
	printf("%d, %s, %d/%d/%04d, %.2f\n", s->registration, s->name, s->birth.day, s->birth.month, s->birth.year, s->average);
}

int main(void) {
	Student *s = NULL;
	int menu, id;

	do {
		scanf("%d", &menu);

		switch (menu)
		{
			case 1:
				s = registerStudent(s);
				break;
			case 2:
				scanf("%d", &id);
				if (s!=NULL){
					s = deleteStudent(s, id);
				}
				else{
					printf("Lista Vazia!\n");
				}
				break;
			case 3:
				if (s==NULL){
					printf("Lista Vazia!\n");
				}
				else{
					printListInverse(s);	
				}
				break;
			case 4:
				printStudent(s);
				break;
			case 5:
				countStudent(s);
				break;
			case 0:
				print(s);
				break;
		}
	}while(menu != 0);

	return 0;
}


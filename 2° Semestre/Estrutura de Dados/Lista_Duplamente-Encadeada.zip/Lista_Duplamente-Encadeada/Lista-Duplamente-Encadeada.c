#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define TAM_NAME 40
#define TAM_REGISTRATION 10


struct Date{
    int day, month, year;
};
typedef struct Date Date;

struct Student{
    char registration[TAM_REGISTRATION];
    char name[TAM_NAME];
    Date birth;
    float average;
    struct Student *next;
    struct Student *prev;
};
typedef struct Student Student;

struct Nodo{
    Student *first;
    Student *last;
};
typedef struct Nodo Nodo;

//Inserindo estudantes na struct
Student *insertStudent(Student *sentinela)
{
    sentinela = (Student *)malloc(sizeof(Student));

    scanf("%s", &sentinela->registration);
    scanf("%s", &sentinela->name);
    scanf("%d/%d/%d", &sentinela->birth.day, &sentinela->birth.month, &sentinela->birth.year);
    scanf("%f", &sentinela->average);
    sentinela->next = NULL;
    sentinela->prev = NULL;
    return sentinela;
}

//Verificando posi��o do elemento
Nodo elementAdd(Nodo element)
{
    Student *aux, *student;
    
	Nodo students = element;
	int verify;
    char code[10];
    scanf("%s", code);
    student = insertStudent(student);

//    Caso entre nesta condi��o n�o h� elemento
    if(students.first == NULL){
        students.first = student;
        students.last = student;
    }else{
        for(aux= students.first; aux!=NULL; aux=aux->next)
        {
            verify = strcmp(aux->registration, code);
            
//          verifica��o para adicionar elemento na ordem
            if(verify==0){
                if(aux->next != NULL){  // verificando se n�o � o ultimo elemento
                    Student *p;
                    student->prev = aux;
                    student->next = aux->next;
                    p = aux->next;
                    p->prev = student;
                    aux->next = student;
                    break;
                }else{   // Inserindo o elemento no final
                    student->prev = students.last;
                    students.last->next = student;
                    students.last = student;
                    break;
                }
            }
        }
//       Adicionando elemento como primeiro
        if(verify != 0){
            student->next = students.first;
            students.first->prev = student;
            students.first = student;
        }
    }
    return students;
}

//Imprime estudantes a partir do 1� 
void listStudentFirst(Nodo sentinel)
{
	Student *aux;

	if(sentinel.first == NULL){
        printf("Lista Vazia!\n");
        return;
    }else{
	   	for(aux=sentinel.first; aux!=NULL; aux=aux->next){
	    	printf("%s, %s, %d/%d/%d, %.2f\n", aux->registration, aux->name, aux->birth.day,aux->birth.month, aux->birth.year, aux->average);
		}
	}
	return;
}

//Imprime estudantes a partir do �ltimo
void listStudentLast(Nodo sentinel){
	Student *aux;

	if(sentinel.last == NULL){
		printf("Lista Vazia!\n");
		return;
	}else{
		for(aux=sentinel.last; aux!=NULL; aux=aux->prev){
			printf("%s, %s, %d/%d/%d, %.2f\n", aux->registration, aux->name, aux->birth.day,aux->birth.month, aux->birth.year, aux->average);
		}
	}
	return;
}

//Deleta um estudante da struct
Nodo deletStudent(Nodo sentinel)
{
	Student *aux;

    char code[10];
    scanf("%s", code);
    if(sentinel.first == NULL){
        printf("Lista Vazia!\n");
        return sentinel;
    }else{
        Student *aux, *p;
        int verify;

        for(aux=sentinel.first; aux!=NULL; aux=aux->next){
			verify = strcmp(aux->registration, code);

			if(verify == 0){ //Verificando o primeiro elemento
                if(aux == sentinel.first){// Caso exista apenas o first
                    if(sentinel.first->next == NULL){
                        sentinel.first = NULL;
                        sentinel.last = NULL;
                    }else{
                        sentinel.first = aux->next;
                        sentinel.last->prev = NULL;
                    }
                    free(aux);
                    continue;
                }else if(aux == sentinel.last){ // Verificando o ultimo elemento
                    sentinel.last = aux->prev;
                    sentinel.last->next = NULL;
                    free(aux);
                    break;
                }else{ // Verificando elemento no meio da lista
                    p = aux->prev;
                    p->next = aux->next;
                    p->prev = aux->prev;
                    free(aux);
                    continue;
                }
            }
        }
        return sentinel;
    }
}

//Limpa a memoria
void clearMemory(Nodo sentinel) //Libera o espa�o na memoria 
{
    Student *aux = sentinel.first, *s;
    
    if(sentinel.first == NULL){
    	return;
	}
    for(s=sentinel.first; s!=NULL; s=s->next){
    	printf("*");
	}
    printf("\n");
    if(aux->next == NULL){
        free(aux);
    }else{
        for(s=sentinel.first->next; s!=NULL; s=s->next)
        {
            free(aux);
            aux = s;
        }
    }
    printf("\n");
}

int main()
{
    Nodo sentinel;
    sentinel.first = NULL;
    sentinel.last = NULL;
    int option;
    
    do{
    	scanf("%d", &option);
    	switch (option)
        {
            case 1:
                sentinel = elementAdd(sentinel);
                break;
            case 2:
            	sentinel = deletStudent(sentinel);
                break;
            case 3:
                listStudentFirst(sentinel);
                break;
            case 4:
            	listStudentLast(sentinel);
                break;
            default:
                break;
        }   	
	}while (option !=0 );
    
    clearMemory(sentinel);
    return 0;
}

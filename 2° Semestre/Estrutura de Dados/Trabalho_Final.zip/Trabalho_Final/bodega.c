#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM_NAME 30
#define TAM_CODE 10

struct _drink { //Struct de bebidas.
    char code[TAM_CODE];
    char name[TAM_NAME];
    int volume;
    float price;
    int qt_stock;
    int isAlcoholic; // 0 - nope, 1 - yep
    struct _drink *next, *prev;
};
typedef struct _drink Drink;
 
typedef struct { //Struct para apontar primeiro e o ultimo da lista.
    Drink *head;
    Drink *tail;
} List;

//Andrei Danelli
Drink *insertDrink(Drink *s) { //Cria um elemento para adicionar na lista.
    system("clear || cls");
    Drink *sentinel = (Drink *)malloc(sizeof(Drink));
    List *lista;
	
	printf("Codigo: ");
    scanf("%s", sentinel->code);
    printf("Bebida: ");
    scanf("%s", sentinel->name);
    printf("Volume (ml): ");
    scanf("%d", &sentinel->volume);
    printf("Preco: ");
    scanf("%f", &sentinel->price);
    printf("Quantidade: ");
    scanf("%d", &sentinel->qt_stock);
    printf("Alcoolica: ");
    scanf("%d", &sentinel->isAlcoholic);

    if(lista->head == NULL) { // Se head for null, não há nada na lista.
        sentinel->next = NULL;
        sentinel->prev = s;

        lista->first = sentinel;
        lista->last = sentinel;
    }
    else{
        (lista->first)->next = sentinel;
        sentinel->prev = (lista->first);
        sentinel->next = NULL;

        lista->first = sentinel;
    }

    return sentinel;
}

//Andrei Danelli
void listDrinks(List sentinel) { //Imprime bebidas cadastradas
	Drink *aux;

	if(sentinel.head == NULL) {
        printf("Nao ha bebidas cadastradas!\n");
        return;
    }
    else {
	    for(aux=sentinel.head; aux!=NULL; aux=aux->next) {
		    printf("%s, %s, %d, %.2f, %d, %d \n", aux->code, aux->name, aux->volume, aux->price, aux->qt_stock, aux->isAlcoholic);
		}
	}
    return;
}

List searchDrink(List sentinel){
    Drink *aux;
    char codigo[TAM_CODE];
    system("clear || cls");

    if(sentinel.head == NULL)
        printf("Nao ha bebidas para serem removidas!\n");
    else{
        printf("Informe o codigo da Bebida que sera removida: ");
        scanf("%s", codigo);

        for(aux=sentinel.head; aux!=NULL; aux=aux->next) {
            if(strcmp(codigo, aux->code) == aux->code)
                printf("%s, %s, %d, %.2f, %d, %d \n", aux->code, aux->name, aux->volume, aux->price, aux->qt_stock, aux->isAlcoholic);
            else
                printf("Bebida nao cadastrada!\n");
        }
    }
    return;
}

List buyDrink(List sentinel){
    Drink *aux;
    char codigo;
    system("clear || cls");

    printf("Informe o codigo da Bebida que deseja comprar: ");
    scanf("%s", codigo);

    for(aux=sentinel.head; aux!=NULL; aux=aux->next) {
        if(codigo == (aux->code))
            aux->qt_stock++;
    }
}

List sellDrink(List sentinel){
    Drink *aux;
    char codigo, sexo;
    system("clear || cls");

    printf("Informe o codigo da Bebida que deseja vender: ");
    scanf("%s", codigo);

    for(aux=sentinel.head; aux!=NULL; aux=aux->next) {
        if(codigo == (aux->code)){
            if(aux->qt_stock > 0){
                printf("Voce tem mais que 18 anos? (S ou N)\n");
                scanf("%c", sexo);
                if((sexo == "S") || (sexo == "s")){
                    aux->qt_stock--;
                    
                }
                else
                    printf("Menor de 18 anos!\n");
            }
            else
                printf("Sem estoque!\n");
                
        }
    }
    return;
}

//Andrei Danelli
List deleteDrink(List sentinel) { //Deleta uma bebida especifica da struct
    Drink *aux;

    char code[TAM_CODE];
    scanf("%s", code);

    if(sentinel.head == NULL) {
        printf("Nao ha bebidas para serem removidas!");
        return;
    }
    else {
        Drink *aux, *p;
        int verify;

        for(aux=sentinel.head; aux!=NULL; aux=aux->next) {

            verify = strcmp(aux->code, code);

            if(verify == 0) { //Verificando o primeiro elemento
                if(aux == sentinel.head) {// Caso exista apenas o first
                    if(sentinel.head->next == NULL) {
                        sentinel.head = NULL;
                        sentinel.tail = NULL;
                    }
                    else {
                        sentinel.head = aux->next;
                        sentinel.tail->prev = NULL;
                    }
                    free(aux);
                    continue;
                }
                else if(aux == sentinel.tail) { // Verificando o ultimo elemento
                    sentinel.tail = aux->prev;
                    sentinel.tail->next = NULL;
                    free(aux);
                    break;
                }
                else { // Verificando elemento no meio da lista
                    p = aux->prev;
                    p->next = aux->next;
                    p->prev = aux->prev;
                    free(aux);
                    continue;
                }
            }
        }
    return sentinel;
    }
}

//Andrei Danelli
void clearMemory(List sentinel) { //Libera espaco na memoria ao finalizar o programa

    Drink *aux = sentinel.head, *s;
   
    if(sentinel.head == NULL)
   	    return;

    for(s=sentinel.head; s!=NULL; s=s->next) {
   	    printf("*");
	    }
    printf("\n");
    if(aux->next == NULL) {
        free(aux);
    }
    else {
        for(s=sentinel.head->next; s!=NULL; s=s->next) {
            free(aux);
            aux = s;
        }
    }
    printf("\n");
}

int main() {
    List sentinel;
    sentinel->head = NULL;
    sentinel->tail = NULL;
    int option;
    
    do {
        printf("\n\t1 - Adicionar Bebidas\n");
        printf("\t2 - Listar Bebidas\n");
        printf("\t3 - Buscar Bebidas\n");
        printf("\t4 - Excluir Bebidas\n");
        printf("\t5 - Comprar Bebidas\n");
        printf("\t6 - Vender Bebidas\n");
        printf("\t0 - Sair do Programa\n");
        printf("\tInsira a opcao que deseja: ");
        scanf("%d", &option);
        
        system("clear || cls");
        switch (option) {
            case 1:
                sentinel = insertDrink(sentinel);
                break;
            case 2:
                listDrinks(sentinel);
                break;
            case 3:
                sentinel = searchDrink(sentinel);
                break;
            case 4:
                sentinel = deleteDrink(sentinel);
                break;
            case 5:
                sentinel = buyDrink(sentinel);
                break;
            case 6:
                sentinel = sellDrink(sentinel);
                break;
            default:
                break;
        }   	
    }while (option !=0 );
    
    clearMemory(sentinel);
    return;
}